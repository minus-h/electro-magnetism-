# this is an illustrated mini-program written to help understanding electrostatic of point charges
# written by HumanArdaki with 'Octave' (free alternative app that warp MATLAB and mainly made and used by linux users), it is also multi-platform
# Octave is compatible with MATLAB but its not fully optional yet! (for example streamlines and professional graphics is not implanted yet)
# but it has many advantages compared to MATLAB (its light,fast,free,fully documented,open source and has an active community with tons of free libraries)
# 
# as far as we have 3 point charge or a useful symetry for shrinking our 3D data to 2D this script is fine

clear

# useful constants:

global eps0 = 8.85 * 10^(-12)
global k = (4*pi*eps0)^(-1)

global micro = 10^(-6)
global nano  = 10^(-9)

# space region defined to work with

global acc = 0.1  # accuracy for numerical analysis and chunking region

Rx = -5:acc:5     # defined space region default from  [-5,5]x[-5,5]
Ry = -5:acc:5

[x,y] = meshgrid(Rx,Ry) 


# useful functions in electrostatic

function PF =  PFOSC(x,y,x0,y0,charge)        # PFOSC: Potential_Field_Of_Single_Charge
  global k
  PF = k*charge*(sqrt((x-x0).^2+(y-y0).^2) + 1).^(-1)   # 1 is an offset to avoid singularity
endfunction

function [EFx EFy] =  EFOSC(x,y,x0,y0,charge) # EFOSC: Electric_Field_Of_Single_Charge
  PF =  PFOSC(x,y,x0,y0,charge)
  [EFx EFy] = gradient(PF)
endfunction


# PotentialField
ptot = PFOSC(x,y,1,1,-2*micro) + PFOSC(x,y,-1,1,+2*micro) + PFOSC(x,y,-1,-1,-2*micro) + PFOSC(x,y,+1,-1,+2*micro) # charge configuration


# in this example we model an electric quadrupole
# (position,charge)
#
#    (-1,+1,+2q)   |   (+1,+1,-2q)
#    --------------|--------------
#    (-1,-1,-2q)   |   (+1,-1,+2q)
#
#

# ElectricField
[Etotx1 Etoty1] = gradient(ptot)         # gradient   of Electric potential
veclen = sqrt((Etotx1).^2 + (Etoty1).^2) # get length of ElectricField vectors
#Etotx = -1*(Etotx1)./veclen              # normalize     ElectricField vectors
#Etoty = -1*(Etoty1)./veclen

relative_veclen = max(max(veclen))/2
Etotx = -1*(Etotx1)./relative_veclen                     # un-normalized ElectricField vectors
Etoty = -1*(Etoty1)./relative_veclen                     # i use maximum vectorlengh and normalize relativly

# graphics

colorDepth = 1000;                 # main colormap
colormap(jet(colorDepth));

subplot(1,2,1)                     # ploting z = phi(x,y)
surfc(x,y,ptot)
shading interp                     # smoothing the surface

hold                               # ploting colorbar to give comparable meaning to colors
subplot(1,2,2)
ptot_colorbar = colorbar
ylabel(ptot_colorbar,'Electric potential (ptot)') # title in plot
hold off

hold                               # ploting contour of phi(x,y) = z by colors  
pcolor(x,y,ptot)
shading interp
hold off

hold                               # adding contour-lines to colors
[ptot_contour ptot_contour_style]  = contour(x,y,ptot,15)
set(ptot_contour_style, ...
    'LineWidth',0.5, ...
    'linecolor','black');
hold off


hold                              # ploting ElectricField arrows on contours (with reduced scale and samples)
quiver(x(1:4:end,1:4:end),y(1:4:end,1:4:end),Etotx(1:4:end,1:4:end)*0.3,Etoty(1:4:end,1:4:end)*0.3,'AutoScale','off')